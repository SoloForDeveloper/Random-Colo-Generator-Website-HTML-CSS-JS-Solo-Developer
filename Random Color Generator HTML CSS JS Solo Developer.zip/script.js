
const btn = document.getElementById("btn");
const color = document.querySelector(".color");

btn.addEventListener("click",function(){
    const randColor = "#"+Math.floor(Math.random()*16777215).toString(16).padStart(6,'0').toUpperCase()

    document.body.style.backgroundColor=randColor;
    color.textContent = randColor;
});